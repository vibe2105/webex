<?php

// Your Webex Teams access token
$accessToken = 'YOUR_ACCESS_TOKEN';

// Assuming you retrieve the room ID dynamically based on your application logic
$roomId = $_POST['roomId'];

// Meeting details from the client-side
$meetingTitle = $_POST['meetingTitle'];
$meetingDate = $_POST['meetingDate'];
$meetingTime = $_POST['meetingTime'];

// Format the start and end times
$startTime = date('c', strtotime("$meetingDate $meetingTime"));
$endTime = date('c', strtotime("$meetingDate $meetingTime +1 hour"));

// Webex Teams API endpoint
$webexApiUrl = 'https://api.ciscospark.com/v1/meetings';

// Prepare the request body
$requestBody = json_encode([
    'title' => $meetingTitle,
    'start' => $startTime,
    'end' => $endTime,
    'roomId' => $roomId,
]);

// Set up cURL to make the request
$ch = curl_init($webexApiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $accessToken,
    'Content-Type: application/json',
]);

// Execute the cURL request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Check for errors and handle the response
if ($httpCode === 200) {
    // Meeting created successfully
    $responseData = json_decode($response, true);

    // Return the meeting join URL to the client
    echo json_encode(['joinUrl' => $responseData['joinUrl']]);
} else {
    // Handle error
    header('HTTP/1.1 ' . $httpCode . ' ' . curl_error($ch));
    echo json_encode(['error' => 'Error creating meeting']);
}

// Close cURL session
curl_close($ch);

?>